//
//  File.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation
import UIKit

class MovieListAssembler {
    class func getMoviesListView() -> UIViewController {
        let movieLocalSource = PopularMoviesLocalService()
        var viewModel : MovieListViewModelProtocol = MovieListViewModel(services: [MoviesListSource.local: movieLocalSource])
        let viewController = MovieListViewController(with: viewModel)
        viewModel.view = viewController
        return viewController
    }
}
