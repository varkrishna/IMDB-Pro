//
//  ViewController.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import UIKit

class MovieListViewController: UIViewController {
    private var viewModel: MovieListViewModelProtocol
    
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.translatesAutoresizingMaskIntoConstraints = false
        table.delegate = self
        table.dataSource = self
        table.register(MovieTableViewCell.self, forCellReuseIdentifier: MovieTableViewCell.identifier)
        return table
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewModel.loadPopularMovies(from: [.local])
    }
    
    private func setupView(){
        view.addSubview(tableView)
        tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        tableView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }

    init(with viewModel: MovieListViewModelProtocol) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension MovieListViewController: MovieListViewProtocol {
    func receivedResponse(from source: MoviesListSource) {
        //reload table
        tableView.reloadData()
    }
    
    func showError(with message: String) {
        let alert = UIAlertController(title: "IMDB Pro", message: message, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "ok", style: .cancel)
        alert.addAction(okButton)
        self.present(alert, animated: true)
    }
    
    
}




extension MovieListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.moviesCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableViewCell.identifier) as? MovieTableViewCell {
            cell.model = viewModel.getMovie(for: indexPath.row)
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension MovieListViewController: UITableViewDelegate {
    
}


