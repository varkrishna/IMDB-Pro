//
//  MovieTableViewCell.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import UIKit

class MovieTableViewCell: UITableViewCell {

    static let identifier = "MovieTableViewCell"
    
    var model: MovieListModel? {
        didSet{
            refreshView()
        }
    }
    
    private lazy var movieImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private lazy var name: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var rating: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var playlist: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var star: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(addToPlaylist), for: .touchUpInside)
        return button
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    private func setupView(){
        self.contentView.addSubview(movieImageView)
        movieImageView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor).isActive = true
        movieImageView.topAnchor.constraint(equalTo: self.contentView.topAnchor).isActive = true
        movieImageView.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor).isActive = true
        movieImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        self.contentView.addSubview(name)
        name.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor).isActive = true
        name.leadingAnchor.constraint(equalTo: movieImageView.trailingAnchor).isActive = true
        name.topAnchor.constraint(equalTo: self.contentView.topAnchor).isActive = true
        
        self.contentView.addSubview(rating)
        rating.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor).isActive = true
        rating.leadingAnchor.constraint(equalTo: movieImageView.trailingAnchor).isActive = true
        rating.topAnchor.constraint(equalTo: self.name.bottomAnchor).isActive = true
        
        self.contentView.addSubview(playlist)
        playlist.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor).isActive = true
        playlist.leadingAnchor.constraint(equalTo: movieImageView.trailingAnchor).isActive = true
        playlist.topAnchor.constraint(equalTo: self.rating.bottomAnchor).isActive = true
        playlist.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: 20).isActive = true
        
        self.contentView.addSubview(star)
        star.topAnchor.constraint(equalTo: self.playlist.bottomAnchor, constant: 5).isActive = true
        star.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -5).isActive = true
        star.widthAnchor.constraint(equalToConstant: 10).isActive = true
        star.heightAnchor.constraint(equalToConstant: 10).isActive = true
    }
    
    private func refreshView(){
        guard let model = model else {
            return
        }

        ImageFetcher.shared.loadImageForURL("https://image.tmdb.org/t/p/w500\(model.bannerURL)") { image, url in
            DispatchQueue.main.async {
                if url == "https://image.tmdb.org/t/p/w500\(model.bannerURL)" {
                    self.movieImageView.image = image
                }
            }
        }
        name.text = model.title
        rating.text = model.rating
        playlist.text  = model.playlist
        
    }
    

    @objc func addToPlaylist(){
        
    }

}
