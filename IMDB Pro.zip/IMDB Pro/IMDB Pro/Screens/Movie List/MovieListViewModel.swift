//
//  MovieListViewModel.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//
import Foundation

protocol MovieListViewModelProtocol {
    var view: MovieListViewProtocol? {get set}
    var moviesCount: Int {get}
    func getMovie(for index: Int) -> MovieListModel
    func loadPopularMovies(from sources: Set<MoviesListSource>)
}

protocol MovieListViewProtocol {
    func receivedResponse(from source: MoviesListSource)
    func showError(with message: String)
}

enum MoviesListSource {
    case network
    case local
}

class MovieListViewModel: MovieListViewModelProtocol {
    
    var view: MovieListViewProtocol?
    var source: Set<MoviesListSource> = [.local]
    var movieListSourceService = [MoviesListSource: MovieListSourcable]()
    var movies = [MovieListModel]()
    var moviesCount: Int {
        return movies.count
    }
    
    init(services: [MoviesListSource: MovieListSourcable]) {
        self.movieListSourceService = services
    }
    
    func loadPopularMovies(from sources: Set<MoviesListSource> = [.local]) {
        for source in sources {
            movieListSourceService[source]?.getMovies(onCompletion: { result in
                switch result {
                case .success(let model):
                    self.parseResponse(model, from: source)
                case .failure(_):
                    self.view?.showError(with: "Some Internal Error")
                }
            })
        }
    }
    
    private func parseResponse(_ response:PopularMoviesResponseModel, from source: MoviesListSource) {
        var result = [MovieListModel]()
        for item in response.movies {
            result.append(MovieListModel(bannerURL: item.posterPath, title: item.title, rating: "\(item.popularity)", playlist: ""))
        }
        self.movies = result
        self.view?.receivedResponse(from: source)
    }

    func getMovie(for index: Int) -> MovieListModel {
        return movies[index]
    }
    
}
