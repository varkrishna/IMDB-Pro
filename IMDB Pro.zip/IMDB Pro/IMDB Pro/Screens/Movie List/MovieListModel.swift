//
//  MovieListModel.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation


struct MovieListModel{
    let bannerURL: String
    let title: String
    let rating: String
    let playlist: String
    
    
}
