//
//  NetworkSession.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation

enum ServiceError: Error {
    case custom(Error)
    case unknown
    case error404
    case invalidResponse
}

class NetworkSesison {
    static var shared = NetworkSesison()
    
    func initiateDataTask(for url: URL, completion: @escaping((Data?) -> Void )) {
        let task = URLSession.shared.dataTask(with: url) { data, response, err in
            completion(data)
        }
        task.resume()
    }
}
