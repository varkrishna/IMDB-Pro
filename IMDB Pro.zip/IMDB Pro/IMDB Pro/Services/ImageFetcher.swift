//
//  ImageFetcher.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation
import UIKit

class ImageFetcher {
    private var cache = [String: UIImage]()
    
    static var shared = ImageFetcher()
    
    func loadImageForURL(_ url: String, completionHandler: @escaping ((UIImage?, String) -> Void)){
        if let cachedImage = cache[url] {
            completionHandler(cachedImage, url)
            return
        }
        guard let validURL = URL(string: url)  else {
            return completionHandler(nil, url)
        }
        NetworkSesison.shared.initiateDataTask(for: validURL) { imageData in
            if let validData = imageData, let image = UIImage(data: validData) {
                self.cache[url] = image
                completionHandler(image, url)
            }
            else{
                completionHandler(nil, url)
            }
        }
    }    
}
