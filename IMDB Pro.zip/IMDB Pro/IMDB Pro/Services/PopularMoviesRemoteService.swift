//
//  PopularMoviesRemoteService.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation

protocol MovieListSourcable {
    func getMovies(onCompletion: ((Result<PopularMoviesResponseModel, ServiceError>) -> Void))
}

class PopularMoviesRemoteService: MovieListSourcable {
    func getMovies(onCompletion: ((Result<PopularMoviesResponseModel, ServiceError>) -> Void)) {
        // Call api
    }
    
    
}
