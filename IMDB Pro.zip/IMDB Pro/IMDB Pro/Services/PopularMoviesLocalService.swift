//
//  PopularMoviesLocalService.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation

class PopularMoviesLocalService: MovieListSourcable {
    func getMovies(onCompletion: ((Result<PopularMoviesResponseModel, ServiceError>) -> Void)) {
        guard let resourceURL = Bundle.main.url(forResource: "PopularMovieList", withExtension: "json") else {
            onCompletion(.failure(.error404))
            return
        }
        do {
            let response = try Data(contentsOf: resourceURL)
            let model = try JSONDecoder().decode(PopularMoviesResponseModel.self, from: response)
            onCompletion(.success(model))
        }
        catch{
            print(error)
            onCompletion(.failure(.invalidResponse))
            return
        }
    }
}

