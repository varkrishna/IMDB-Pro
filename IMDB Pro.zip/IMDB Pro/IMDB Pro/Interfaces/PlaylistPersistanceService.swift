//
//  PlaylistPersistanceService.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation

typealias MovieName = String
typealias PlaylistName = String

protocol PlaylistPersistanceProtocol {
    func savePlaylists(_ playlist: [PlaylistName: [MovieName]])
    func deletePaylist()
    func loadPlayList() -> [PlaylistName: [MovieName]]?
}


class PlaylistPersistance: PlaylistPersistanceProtocol{
    let db = UserDefaults.standard
    
    func savePlaylists(_ playlist: [PlaylistName: [MovieName]]) {
        db.set(playlist, forKey: "playlist")
    }
    
    func deletePaylist(){
        db.removeObject(forKey: "playlist")
    }
    
    func loadPlayList() -> [PlaylistName: [MovieName]]? {
        db.object(forKey: "playlist") as? [PlaylistName: [MovieName]]
    }
}
