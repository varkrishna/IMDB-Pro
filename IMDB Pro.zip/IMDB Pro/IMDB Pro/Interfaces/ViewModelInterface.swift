//
//  ViewModelInterface.swift
//  IMDB Pro
//
//  Created by Krishan Kumar Varshney on 10/09/22.
//

import Foundation
import UIKit


protocol BaseViewModel {
    var view: UIViewController? {get set}
    func viewDidLoad()
    func viewWilAppear()
    func viewDidDisappear()
    func viewWillDisappear()
}
